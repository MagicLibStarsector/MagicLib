# GitHub Releaser

Every time you make+push a new git tag, it'll create a GitHub release for you.

## Steps

1. Commit and push some changes, then create and push a new tag.

Optionally, you may edit "blacklist.txt", which contains regex expressions of files that will NOT be included in the released mod folder (eg psd files)
